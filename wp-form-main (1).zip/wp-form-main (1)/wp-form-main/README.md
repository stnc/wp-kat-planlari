stncGonulluOl_errors  bu fonksiyon bağışdada kullnılcak 




dynamnic form 
https://jqueryvalidation.org/files/demo/dynamic-totals.html
bunun bir örneğini de konckout da gordum 




https://knockoutjs.com/examples/contactsEditor.html


https://gist.github.com/mehrshaddarzi/f12c8ae255b295b39c03bbe0fc3a5474#file-page-php
https://gist.github.com/mehrshaddarzi


//upload ıcın 
//https://preview.keenthemes.com/craft/documentation/forms/dropzonejs.html