//https://www.inmotionhosting.com/support/edu/wordpress/save-wordpress-plugin-settings-with-form/
/*  ///OLD Sinlge menu 
function my_admin_menu()
{
    add_menu_page(

        __('Sample page', 'my-textdomain'),

        __('Sample menu', 'my-textdomain'),
        'manage_options',
        'sample-page',
        'my_admin_page_contents',
        'dashicons-schedule',
        3
    );
}

add_action('admin_menu', 'my_admin_menu');

*/




//https://wordpress.stackexchange.com/questions/342433/error-options-page-not-found-saving-settings-page-with-tabs



//https://stackoverflow.com/questions/45711303/wordpress-and-jwt-with-custom-api-rest-endpoint
//https://wordpress.org/support/topic/custom-endpoint-is-unprotected/
//https://www.bethedev.com/2016/12/insert-data-in-database-using-form-in.html

//https://gist.github.com/swapnil-webonise/6792192


//https://github.com/imranhsayed/ihs-forms/blob/master/wordpress-form.php